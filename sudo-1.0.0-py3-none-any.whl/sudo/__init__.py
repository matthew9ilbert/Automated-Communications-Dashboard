#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = """wesinator"""
__version__ = '1.0.0'

from .sudo import run_as_sudo, run_cmd
